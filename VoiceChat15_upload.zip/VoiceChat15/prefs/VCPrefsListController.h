#import <Preferences/PSListController.h>

@interface VCPrefsListController : PSListController
@end
