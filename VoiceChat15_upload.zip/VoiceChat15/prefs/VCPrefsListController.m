#import "VCPrefsListController.h"
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <Preferences/PSSpecifier.h>

// VoiceChat15 prefs (stage 0, 0.1.3).
//
// The TTS-rate chooser deliberately does NOT use a PSLinkListCell /
// PSListItemsController any more:
//   - 0.1.0/0.1.1: the cell had no detail controller (and used
//     validValues/validTitles), so tapping it did nothing at all.
//   - 0.1.2: rewritten with detail=PSListItemsController +
//     values/titles — tapping it then CRASHED the Settings app on
//     the real device (confirmed by the user, 2026-11-19).
// 0.1.3 therefore picks the rate with three plain PSButtonCell
// rows — the same primitive as the test buttons, which are proven
// to work on this device. The currently selected row gets a
// "（今これ）" suffix, refreshed on every load/reload, and picking
// a rate immediately speaks a sample at that rate.

static AVSpeechSynthesizer *vcSynth = nil;

static NSInteger VCCurrentRate(void) {
    NSInteger rateSel = 1;
    CFPreferencesAppSynchronize(CFSTR("com.tori.voicechat15"));
    CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("TTSRate"),
                                                    CFSTR("com.tori.voicechat15"));
    if (v) {
        if (CFGetTypeID(v) == CFNumberGetTypeID()) {
            rateSel = [(__bridge NSNumber *)v integerValue];
        }
        CFRelease(v);
    }
    if (rateSel < 0) rateSel = 0;
    if (rateSel > 2) rateSel = 2;
    return rateSel;
}

static float VCRateValue(NSInteger rateSel) {
    if (rateSel == 0) return 0.42f; // slow
    if (rateSel == 2) return 0.58f; // fast
    return AVSpeechUtteranceDefaultSpeechRate; // 0.5, normal
}

static void VCSpeak(NSString *text, NSInteger rateSel) {
    if (!vcSynth) vcSynth = [[AVSpeechSynthesizer alloc] init];
    if (vcSynth.isSpeaking) [vcSynth stopSpeakingAtBoundary:AVSpeechBoundaryImmediate];
    AVSpeechUtterance *u = [AVSpeechUtterance speechUtteranceWithString:text];
    AVSpeechSynthesisVoice *voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"ja-JP"];
    if (voice) u.voice = voice;
    u.rate = VCRateValue(rateSel);
    [vcSynth speakUtterance:u];
}

@implementation VCPrefsListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
        [self vcRefreshRateLabels];
    }
    return _specifiers;
}

// Adds "（今これ）" to the button row of the currently selected
// rate and removes it from the other two. Runs entirely on
// specifier properties; wrapped so a surprise here can never
// take the Settings pane down.
- (void)vcRefreshRateLabels {
    @try {
        NSInteger cur = VCCurrentRate();
        NSDictionary *base = @{ @"rate_slow":   @[@"ゆっくり", @0],
                                @"rate_normal": @[@"ふつう",   @1],
                                @"rate_fast":   @[@"はやい",   @2] };
        for (PSSpecifier *spec in _specifiers) {
            NSString *ident = nil;
            @try { ident = [spec identifier]; } @catch (__unused id e) {}
            if (!ident) {
                @try { ident = [spec propertyForKey:@"id"]; } @catch (__unused id e) {}
            }
            NSArray *pair = ident ? base[ident] : nil;
            if (!pair) continue;
            NSString *label = pair[0];
            if ([pair[1] integerValue] == cur) label = [label stringByAppendingString:@"（今これ）"];
            [spec setProperty:label forKey:@"label"];
            spec.name = label;
        }
    } @catch (__unused id e) {}
}

- (void)vcSetRate:(NSInteger)rateSel sample:(NSString *)sample {
    CFPreferencesSetAppValue(CFSTR("TTSRate"),
                             (__bridge CFPropertyListRef)@(rateSel),
                             CFSTR("com.tori.voicechat15"));
    CFPreferencesAppSynchronize(CFSTR("com.tori.voicechat15"));
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                         CFSTR("com.tori.voicechat15.changed"),
                                         NULL, NULL, true);
    [self reloadSpecifiers];
    VCSpeak(sample, rateSel);
}

- (void)setRateSlow:(id)sender {
    (void)sender;
    [self vcSetRate:0 sample:@"ゆっくりの速さにしました。これで読み上げます。"];
}

- (void)setRateNormal:(id)sender {
    (void)sender;
    [self vcSetRate:1 sample:@"ふつうの速さにしました。これで読み上げます。"];
}

- (void)setRateFast:(id)sender {
    (void)sender;
    [self vcSetRate:2 sample:@"はやい速さにしました。これで読み上げます。"];
}

// TTS test: speaks a fixed Japanese sentence at the currently
// selected rate. Runs inside the Settings app, independent of
// the tweak dylib.
- (void)testTTS:(id)sender {
    (void)sender;
    VCSpeak(@"こんにちは。ボイスチャット15の、テスト読み上げです。この声で、チャットジーピーティーの答えを読み上げます。",
            VCCurrentRate());
}

- (void)stopTTS:(id)sender {
    (void)sender;
    if (vcSynth.isSpeaking) [vcSynth stopSpeakingAtBoundary:AVSpeechBoundaryImmediate];
}

// The tweak (SpringBoard, same mobile user) owns the log file, and
// the Settings app also runs as mobile, so it can remove it directly.
- (void)clearLog:(id)sender {
    (void)sender;
    for (NSString *path in @[@"/var/mobile/Library/Logs/VoiceChat15.log",
                             @"/var/tmp/VoiceChat15.log"]) {
        [NSFileManager.defaultManager removeItemAtPath:path error:nil];
    }
}

@end
