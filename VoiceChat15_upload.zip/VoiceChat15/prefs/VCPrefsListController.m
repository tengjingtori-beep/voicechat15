#import "VCPrefsListController.h"
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@implementation VCPrefsListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

// TTS test: speaks a fixed Japanese sentence with AVSpeechSynthesizer
// at the rate selected in Settings. This runs inside the Settings
// app, independent of the tweak dylib, so it separates "TTS works on
// this phone" from every later stage (mic, WebView, auto-send).
// The synthesizer is kept in a static so it is not released while
// it is still speaking.
static AVSpeechSynthesizer *vcSynth = nil;

- (void)testTTS:(id)sender {
    (void)sender;
    NSInteger rateSel = 1;
    // Read the freshest value: the list controller writes into the
    // same prefs domain from this process, and a synchronize first
    // guarantees the test button never speaks at a stale rate.
    CFPreferencesAppSynchronize(CFSTR("com.tori.voicechat15"));
    CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("TTSRate"),
                                                    CFSTR("com.tori.voicechat15"));
    if (v) {
        rateSel = [(__bridge NSNumber *)v integerValue];
        CFRelease(v);
    }
    if (rateSel < 0) rateSel = 0;
    if (rateSel > 2) rateSel = 2;

    float rate = AVSpeechUtteranceDefaultSpeechRate; // 0.5, normal
    if (rateSel == 0) rate = 0.42f;                  // slow
    if (rateSel == 2) rate = 0.58f;                  // fast

    if (!vcSynth) vcSynth = [[AVSpeechSynthesizer alloc] init];
    if (vcSynth.isSpeaking) [vcSynth stopSpeakingAtBoundary:AVSpeechBoundaryImmediate];

    AVSpeechUtterance *u = [AVSpeechUtterance
        speechUtteranceWithString:@"こんにちは。ボイスチャット15の、テスト読み上げです。この声で、チャットジーピーティーの答えを読み上げます。"];
    AVSpeechSynthesisVoice *voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"ja-JP"];
    if (voice) u.voice = voice;
    u.rate = rate;
    [vcSynth speakUtterance:u];
}

- (void)stopTTS:(id)sender {
    (void)sender;
    if (vcSynth.isSpeaking) [vcSynth stopSpeakingAtBoundary:AVSpeechBoundaryImmediate];
}

// The tweak (SpringBoard, same mobile user) owns the log file, and
// the Settings app also runs as mobile, so it can remove it directly.
- (void)clearLog:(id)sender {
    (void)sender;
    for (NSString *path in @[@"/var/mobile/Library/Logs/VoiceChat15.log",
                             @"/var/tmp/VoiceChat15.log"]) {
        [NSFileManager.defaultManager removeItemAtPath:path error:nil];
    }
}

@end
