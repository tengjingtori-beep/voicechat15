// VoiceChat15 — entry point (stage 0, skeleton)
// iPhone 7 / iOS 15 / Dopamine (rootless).
// The filter plist injects this dylib into SpringBoard ONLY.
// Stage 0 does exactly one thing: when SpringBoard finishes
// launching, start the manager (log + prefs + failure brake).
// No hooks into other apps, no microphone, no WebView yet —
// those arrive one stage at a time, after each stage passes on
// the real device, and the WebView/TTS work is planned to live
// OUTSIDE SpringBoard so a failure there can never Safe-Mode
// the home screen.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "VCManager.h"

@interface SpringBoard : UIApplication
@end

static void vcPrefsChanged(CFNotificationCenterRef center, void *observer,
                           CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[VCManager shared] reloadPrefs];
    });
}

%group VCSpringBoardGroup
%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
    %orig;
    VCLog(@"SPRINGBOARD_LAUNCHED");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[VCManager shared] setup];
    });
}
%end
%end

%ctor {
    @autoreleasepool {
        VCLoadPrefs();
        NSString *bid = [[NSBundle mainBundle] bundleIdentifier] ?: @"?";
        if ([bid isEqualToString:@"com.apple.springboard"]) {
            CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
                vcPrefsChanged, (__bridge CFStringRef)@"com.tori.voicechat15.changed", NULL,
                CFNotificationSuspensionBehaviorDeliverImmediately);
            VCLog(@"DYLIB_LOADED version=0.1.3 process=%@", bid);
            %init(VCSpringBoardGroup);
        }
    }
}
