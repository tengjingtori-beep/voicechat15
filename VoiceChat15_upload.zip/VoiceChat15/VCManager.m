// VoiceChat15 — core (stage 0, skeleton)
//
// Stage 0 proves only the foundation on the real device, exactly
// like Future15 stage 0 did:
//   - the dylib loads into SpringBoard only (narrow filter on
//     purpose: no UIKit-wide injection in the skeleton),
//   - the log file is written,
//   - prefs are read and re-read when Settings changes them,
//   - the failure brake exists (5 exceptions -> all activity stops
//     until respring).
// No microphone, no WebView, no network in this stage. The TTS test
// button lives in the prefs bundle and runs inside the Settings
// app, independent of this dylib.

#import "VCManager.h"
#import <UIKit/UIKit.h>

NSString * const kVCPrefsID = @"com.tori.voicechat15";
NSString * const kVCPrefsChanged = @"com.tori.voicechat15.changed";
static NSString * const kVCVersion = @"0.1.3";

// ---------- prefs ----------
static BOOL prefEnabled = YES;
static BOOL prefVoiceChat = NO;
static BOOL prefVocalLink = NO;
static NSInteger prefTTSRate = 1; // 0=slow 1=normal 2=fast
static NSString *prefTriggerWord = @"チャット";

static id VCAppValue(NSString *key) {
    return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kVCPrefsID);
}

void VCLoadPrefs(void) {
    @try {
        id v;
        v = VCAppValue(@"Enabled");         if (v) prefEnabled = [v boolValue];
        v = VCAppValue(@"VoiceChatEnabled"); if (v) prefVoiceChat = [v boolValue];
        v = VCAppValue(@"VocalLinkEnabled"); if (v) prefVocalLink = [v boolValue];
        v = VCAppValue(@"TTSRate");          if (v) prefTTSRate = [v integerValue];
        if (prefTTSRate < 0) prefTTSRate = 0;
        if (prefTTSRate > 2) prefTTSRate = 2;
        v = VCAppValue(@"TriggerWord");
        if (v && [(id)v isKindOfClass:[NSString class]] && [(NSString *)v length] > 0) {
            prefTriggerWord = [(NSString *)v copy];
        }
        CFPreferencesAppSynchronize((__bridge CFStringRef)kVCPrefsID);
    } @catch (__unused id e) {}
}

// ---------- log ----------
static NSFileHandle *vcLogHandle = nil;
static dispatch_queue_t vcLogQueue = nil;

static NSString *VCLogPath(void) {
    NSString *p = @"/var/mobile/Library/Logs/VoiceChat15.log";
    if ([NSFileManager.defaultManager fileExistsAtPath:p]) return p;
    NSString *dir = @"/var/mobile/Library/Logs";
    if ([NSFileManager.defaultManager createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil] &&
        [NSFileManager.defaultManager createFileAtPath:p contents:nil attributes:nil]) return p;
    return @"/var/tmp/VoiceChat15.log";
}

void VCLog(NSString *format, ...) {
    @try {
        va_list ap; va_start(ap, format);
        NSString *msg = [[NSString alloc] initWithFormat:format arguments:ap];
        va_end(ap);
        if (!vcLogQueue) vcLogQueue = dispatch_queue_create("com.tori.voicechat15.log", DISPATCH_QUEUE_SERIAL);
        dispatch_async(vcLogQueue, ^{
            @try {
                if (!vcLogHandle) {
                    NSString *path = VCLogPath();
                    [NSFileManager.defaultManager createFileAtPath:path contents:nil attributes:nil];
                    vcLogHandle = [NSFileHandle fileHandleForWritingAtPath:path];
                }
                [vcLogHandle seekToEndOfFile];
                NSString *line = [NSString stringWithFormat:@"[%@] %@\n",
                    [NSDateFormatter localizedStringFromDate:[NSDate date] dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterMediumStyle], msg];
                [vcLogHandle writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
                [vcLogHandle synchronizeFile];
            } @catch (__unused id e) {}
        });
    } @catch (__unused id e) {}
}

// ---------- failure brake ----------
// After kVCBrakeThreshold exceptions anywhere in the manager, the
// brake engages: all feature activity must check +[VCManager brakeOn]
// (and the master Enabled switch) before doing anything. The brake
// never auto-releases; a respring restarts the count. This is the
// mechanism that keeps one broken feature from looping into a
// SpringBoard crash / Safe Mode cycle.
static NSInteger gExceptionCount = 0;
static BOOL gBrakeOn = NO;
static const NSInteger kVCBrakeThreshold = 5;

void VCNoteException(NSString *where, id error) {
    gExceptionCount++;
    VCLog(@"EXCEPTION %@: %@ (count=%ld)", where, error, (long)gExceptionCount);
    if (!gBrakeOn && gExceptionCount >= kVCBrakeThreshold) {
        gBrakeOn = YES;
        VCLog(@"BRAKE_ON exceptions reached %ld: all feature activity is stopped until respring", (long)gExceptionCount);
    }
}

// ---------- manager ----------
@interface VCManager ()
@property (nonatomic) BOOL setupDone;
@end

@implementation VCManager

+ (instancetype)shared {
    static VCManager *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[VCManager alloc] init]; });
    return s;
}

+ (BOOL)brakeOn { return gBrakeOn; }

- (void)reloadPrefs {
    VCLoadPrefs();
    VCLog(@"PREFS enabled=%d voicechat=%d vocalLink=%d ttsRate=%ld trigger=%@ brake=%d",
          prefEnabled, prefVoiceChat, prefVocalLink, (long)prefTTSRate,
          prefTriggerWord, gBrakeOn);
}

- (void)setup {
    if (self.setupDone) return;
    self.setupDone = YES;
    @try {
        VCLog(@"SETUP_START version=%@", kVCVersion);
        [self reloadPrefs];
        VCLog(@"STAGE0 skeleton only: no mic, no WebView, no network. TTS test lives in Settings.");
        VCLog(@"SETUP_DONE");
    } @catch (id e) {
        VCNoteException(@"setup", e);
    }
}

@end
