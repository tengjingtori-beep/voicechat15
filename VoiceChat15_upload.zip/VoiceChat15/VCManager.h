#import <Foundation/Foundation.h>

// VoiceChat15 manager (stage 0, skeleton):
// owns the diagnostic log, the prefs snapshot and the failure brake.
// Later stages plug in here:
//   stage 1: visible WebView experiment for chatgpt.com
//   stage 2: automatic send / answer extraction in the background
//   stage 3: voice trigger (shared with Future15 Vocal Shortcuts),
//            question capture and TTS read-out
// Every feature path must pass through the brake and write to the
// log so a failure can be traced from the log alone.
@interface VCManager : NSObject
+ (instancetype)shared;
- (void)setup;
- (void)reloadPrefs;
+ (BOOL)brakeOn;
@end

// Shared prefs / logging / brake helpers used by Tweak.x too.
void VCLoadPrefs(void);
void VCLog(NSString *format, ...);
void VCNoteException(NSString *where, id error);
